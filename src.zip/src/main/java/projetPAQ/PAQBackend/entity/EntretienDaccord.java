package projetPAQ.PAQBackend.entity;




import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class EntretienDaccord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Date date;
    private String typeErreur;
    private String details;
    private String decision;
    private boolean deleted = false; // Champ pour le soft delete

    @ManyToOne
    @JoinColumn(name = "id_collaborateur")
    private Collaborateur collaborateur;

    @ManyToOne
    @JoinColumn(name = "id_user")
    private User user; // Superviseur direct

   
    private boolean validated = false; // Nouvel attribut pour l'état de validation
    
    
}