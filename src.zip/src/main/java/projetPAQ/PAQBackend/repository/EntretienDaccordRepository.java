package projetPAQ.PAQBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import projetPAQ.PAQBackend.entity.EntretienDaccord;

import java.util.List;
import java.util.Optional;

public interface EntretienDaccordRepository extends JpaRepository<EntretienDaccord, Integer> {

    // Récupérer tous les entretiens non supprimés
    List<EntretienDaccord> findByDeletedFalse();

    // Récupérer un entretien non supprimé par ID
    Optional<EntretienDaccord> findByIdAndDeletedFalse(Integer id);

    // Récupérer les entretiens d'un collaborateur non supprimés
    List<EntretienDaccord> findByCollaborateurIdAndDeletedFalse(Integer collaborateurId);

    // Récupérer les entretiens supprimés (corbeille)
    List<EntretienDaccord> findByDeletedTrue();
    
    
    
    List<EntretienDaccord> findByUserIdAndDeletedFalse(Integer userId);
    List<EntretienDaccord> findByUserIdAndDeletedTrue(Integer userId);
    
    
}