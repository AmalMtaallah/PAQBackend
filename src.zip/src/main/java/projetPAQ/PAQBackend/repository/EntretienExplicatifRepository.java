package projetPAQ.PAQBackend.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import projetPAQ.PAQBackend.entity.EntretienExplicatif;

public interface EntretienExplicatifRepository extends JpaRepository<EntretienExplicatif, Integer> {
	 List<EntretienExplicatif> findByCollaborateurId(Integer collaborateurId);
	// Récupérer tous les entretiens non supprimés
	    List<EntretienExplicatif> findByDeletedFalse();

	    // Récupérer les entretiens par collaborateur non supprimés
	    List<EntretienExplicatif> findByCollaborateurIdAndDeletedFalse(Integer collaborateurId);
	   // Récupérer un entretien par son ID uniquement s'il n'est pas supprimé
	    Optional<EntretienExplicatif> findByIdAndDeletedFalse(Integer id);
	    
	    List<EntretienExplicatif> findByUserIdAndDeletedFalse(Integer userId);
	    List<EntretienExplicatif> findByUserIdAndDeletedTrue(Integer userId);
}
