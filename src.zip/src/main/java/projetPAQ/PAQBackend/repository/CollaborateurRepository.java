package projetPAQ.PAQBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import projetPAQ.PAQBackend.entity.Collaborateur;

import java.util.List;

public interface CollaborateurRepository extends JpaRepository<Collaborateur, Integer> {
	//List<Collaborateur> findByUserId(Long long1);
	
	 @Query("SELECT c FROM Collaborateur c JOIN FETCH c.user")
	    List<Collaborateur> findAllWithUsers();
	 
	 List<Collaborateur> findByUserId(Long userId);
	 
	 
	 // Méthode pour rechercher des collaborateurs par nom et prénom
	  /*  @Query("SELECT c FROM Collaborateur c WHERE LOWER(c.nom) LIKE LOWER(CONCAT('%', :nom, '%')) " +
	           "AND LOWER(c.prenom) LIKE LOWER(CONCAT('%', :prenom, '%'))")
	    List<Collaborateur> findByNomAndPrenom(@Param("nom") String nom, @Param("prenom") String prenom);
	    */
	    
	    
	    
	   // Récupérer les collaborateurs non supprimés
	    List<Collaborateur> findByDeletedFalse();

	    // Récupérer les collaborateurs supprimés (corbeille)
	    List<Collaborateur> findByDeletedTrue();

	    // Marquer un collaborateur comme supprimé
	    @Modifying
	    @Query("UPDATE Collaborateur c SET c.deleted = true WHERE c.id = :id")
	    void softDeleteById(@Param("id") Integer id);

	    // Rechercher des collaborateurs par nom et prénom (non supprimés)
	    @Query("SELECT c FROM Collaborateur c WHERE LOWER(c.nom) LIKE LOWER(CONCAT('%', :nom, '%')) " +
	           "AND LOWER(c.prenom) LIKE LOWER(CONCAT('%', :prenom, '%')) AND c.deleted = false")
	    List<Collaborateur> findByNomAndPrenom(@Param("nom") String nom, @Param("prenom") String prenom);

	    // Récupérer les collaborateurs par ID d'utilisateur (non supprimés)
	    List<Collaborateur> findByUserIdAndDeletedFalse(Long userId);
	    
	    
    
}