package projetPAQ.PAQBackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import projetPAQ.PAQBackend.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByDestinataireEmailAndIsReadFalse(String destinataireEmail);
    List<Notification> findByDestinataireEmail(String destinataireEmail);
}