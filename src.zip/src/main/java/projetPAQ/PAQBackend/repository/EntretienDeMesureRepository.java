package projetPAQ.PAQBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import projetPAQ.PAQBackend.entity.EntretienDeMesure;

import java.util.List;
import java.util.Optional;

public interface EntretienDeMesureRepository extends JpaRepository<EntretienDeMesure, Integer> {

    // Récupérer tous les entretiens non supprimés
    List<EntretienDeMesure> findByDeletedFalse();

    // Récupérer un entretien non supprimé par ID
    Optional<EntretienDeMesure> findByIdAndDeletedFalse(Integer id);

    // Récupérer les entretiens d'un collaborateur non supprimés
    List<EntretienDeMesure> findByCollaborateurIdAndDeletedFalse(Integer collaborateurId);

    // Récupérer les entretiens supprimés (corbeille)
    List<EntretienDeMesure> findByDeletedTrue();

    // Récupérer les entretiens par userId (non supprimés)
    List<EntretienDeMesure> findByUserIdAndDeletedFalse(Integer userId);

    // Récupérer les entretiens supprimés par userId
    List<EntretienDeMesure> findByUserIdAndDeletedTrue(Integer userId);
}


