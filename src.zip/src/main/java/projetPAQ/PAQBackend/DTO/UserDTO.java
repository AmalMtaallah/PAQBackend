package projetPAQ.PAQBackend.DTO;

import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String role;

    // Getters and Setters
}