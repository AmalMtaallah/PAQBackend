package projetPAQ.PAQBackend.DTO;

import java.sql.Date;
import lombok.Data;

@Data
public class EntretienDeMesureDTO {
    private Integer id;
    private Date date;
    private String typeErreur;
    private String details;
    private String decision;
    private Integer collaborateurId;
    private Long userId;
    private Long validatedQMseegmetUserId; // ID de l'utilisateur qui a validé QMseegmet
    private Long validatedSGLUserId; // ID de l'utilisateur qui a validé SGL
    private boolean deleted;
}