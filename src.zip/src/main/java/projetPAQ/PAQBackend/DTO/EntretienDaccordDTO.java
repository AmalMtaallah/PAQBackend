package projetPAQ.PAQBackend.DTO;

import java.sql.Date;
//import java.time.LocalDate;
import lombok.Data;
@Data
public class EntretienDaccordDTO {
    private Integer id;
    private Date date;
    private String typeErreur;
    private String details;
    private String decision;
    private Integer collaborateurId;
    private Long userId;
    private Boolean validated;

 

   
}