package projetPAQ.PAQBackend.DTO;


import java.util.Date;

public class CollaborateurDTO {
    private Integer id;
    private String nom;
    private String prenom;
    private Date dateEmbauche;
    private String seg;
    private Long userId; // ID de l'utilisateur qui a créé le collaborateur

    // Constructeur
    public CollaborateurDTO(Integer id, String nom, String prenom, Date dateEmbauche, String seg, Long long1) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateEmbauche = dateEmbauche;
        this.seg = seg;
        this.userId = long1; // Initialisez l'ID de l'utilisateur
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Date getDateEmbauche() {
		return dateEmbauche;
	}

	public void setDateEmbauche(Date dateEmbauche) {
		this.dateEmbauche = dateEmbauche;
	}

	public String getSeg() {
		return seg;
	}

	public void setSeg(String seg) {
		this.seg = seg;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}