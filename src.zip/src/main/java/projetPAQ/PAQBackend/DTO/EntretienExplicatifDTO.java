package projetPAQ.PAQBackend.DTO;



import java.sql.Date;

public class EntretienExplicatifDTO {
    private Integer id;
    private Date date;
    private String typeErreur;
    private String details;
    private String decision;
    private Integer collaborateurId;
    private Long userId;
    private Boolean validated;

    public Boolean getValidated() {
		return validated;
	}

	public void setValidated(Boolean validated) {
		this.validated = validated;
	}

	// Getters et setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTypeErreur() {
        return typeErreur;
    }

    public void setTypeErreur(String typeErreur) {
        this.typeErreur = typeErreur;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public Integer getCollaborateurId() {
        return collaborateurId;
    }

    public void setCollaborateurId(Integer collaborateurId) {
        this.collaborateurId = collaborateurId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long long1) {
        this.userId = long1;
    }
}
