package projetPAQ.PAQBackend.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import projetPAQ.PAQBackend.configuration.JwtUtils;
import projetPAQ.PAQBackend.entity.User;
import projetPAQ.PAQBackend.repository.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authenticationManager;
   /* // Constructeur manuel
    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder, 
                          JwtUtils jwtUtils, AuthenticationManager authenticationManager) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
        this.authenticationManager = authenticationManager;
    }*/
   /* @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();

        if (userRepository.findByEmail(user.getEmail()) != null) {
            response.put("error", "Email already exists");
            response.put("status", HttpStatus.BAD_REQUEST.value());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);

        response.put("message", "User registered successfully");
        response.put("status", HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }*/
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();

        // Vérifiez si l'email est déjà pris
        if (userRepository.findByEmail(user.getEmail()) != null) {
            response.put("error", "Email already exists");
            response.put("status", HttpStatus.BAD_REQUEST.value());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Vérifiez si l'ID est déjà pris
        if (userRepository.existsById(user.getId())) {
            response.put("error", "ID already exists");
            response.put("status", HttpStatus.BAD_REQUEST.value());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        // Hacher le mot de passe avant de l'enregistrer
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);

        response.put("message", "User registered successfully");
        response.put("status", HttpStatus.OK.value());
        return ResponseEntity.ok(response);
    }


   /* @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
            );

            User authenticatedUser = userRepository.findByEmail(user.getEmail());
            String token = jwtUtils.generateToken(authenticatedUser.getEmail(), authenticatedUser.getRole());

            Map<String, Object> authData = new HashMap<>();
            authData.put("token", token);
            authData.put("type", "Bearer");
            authData.put("role", authenticatedUser.getRole()); // Retourner aussi le rôle

            return ResponseEntity.ok(authData);

        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
    }*/

    
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword())
            );

            User authenticatedUser = userRepository.findByEmail(user.getEmail());
            String token = jwtUtils.generateToken(authenticatedUser.getEmail(), authenticatedUser.getRole());

            Map<String, Object> authData = new HashMap<>();
            authData.put("token", token);
            authData.put("type", "Bearer");
            authData.put("user", Map.of(
                "id", authenticatedUser.getId(),
                "firstName", authenticatedUser.getFirstName(),
                "lastName", authenticatedUser.getLastName(),
                "email", authenticatedUser.getEmail(),
                "role", authenticatedUser.getRole(),
                "hireDate", authenticatedUser.getHireDate()
            ));

            return ResponseEntity.ok(authData);

        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
        }
    }

}