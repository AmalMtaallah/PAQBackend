package projetPAQ.PAQBackend.service;


import projetPAQ.PAQBackend.entity.Collaborateur;
import projetPAQ.PAQBackend.entity.EntretienExplicatif;
import projetPAQ.PAQBackend.repository.CollaborateurRepository;
import projetPAQ.PAQBackend.repository.EntretienExplicatifRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CollaborateurService {

    private final CollaborateurRepository collaborateurRepository;
   
    @Autowired
    private EntretienExplicatifRepository entretienExplicatifRepository;

    public CollaborateurService(CollaborateurRepository collaborateurRepository) {
        this.collaborateurRepository = collaborateurRepository;
    }

    public List<Collaborateur> getAllCollaborateurs() {
        return collaborateurRepository.findAll();
    }

    public Collaborateur getCollaborateurById(Integer id) {
        return collaborateurRepository.findById(id).orElse(null);
    }

   /* public Collaborateur createCollaborateur(Collaborateur collaborateur, String userRole) {
        if (!"SL".equals(userRole)) {
            throw new RuntimeException("Seuls les utilisateurs avec le rôle SL peuvent ajouter un collaborateur.");
        }
        return collaborateurRepository.save(collaborateur);
    }*/

    public Optional<Collaborateur> updateCollaborateur(Integer id, Collaborateur newCollaborateur) {
        return collaborateurRepository.findById(id).map(collaborateur -> {
            collaborateur.setNom(newCollaborateur.getNom());
            collaborateur.setPrenom(newCollaborateur.getPrenom());
            collaborateur.setDateEmbauche(newCollaborateur.getDateEmbauche());
            collaborateur.setSeg(newCollaborateur.getSeg());
            return collaborateurRepository.save(collaborateur);
        });
    }

    public void deleteCollaborateur(Integer id) {
        collaborateurRepository.deleteById(id);
    }
    
    public List<Collaborateur> getCollaborateursByUserId(Long userId) {
        return collaborateurRepository.findByUserId(userId);}
    
    
    
    public Collaborateur createCollaborateur(Collaborateur collaborateur, String userRole) {
        if (!"SL".equals(userRole)) {
            throw new RuntimeException("Seuls les utilisateurs avec le rôle SL peuvent ajouter un collaborateur.");
        }

        // Vérifier si l'ID est fourni et unique
        if (collaborateur.getId() == null) {
            throw new RuntimeException("ID is required");
        }

        if (collaborateurRepository.existsById(collaborateur.getId())) {
            throw new RuntimeException("ID must be unique");
        }

        return collaborateurRepository.save(collaborateur);
    }
    
    
    
  

  /*  public ResponseEntity<?> deleteCollaborateur(Integer id, String token) {
        // Vérifiez si le collaborateur a des entretiens associés
        List<EntretienExplicatif> entretiens = entretienExplicatifRepository.findByCollaborateurId(id);
        if (!entretiens.isEmpty()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Le collaborateur a des entretiens associés, suppression impossible");
        }

        // Marquer le collaborateur comme supprimé (archivé)
        collaborateurRepository.softDeleteById(id);

        return ResponseEntity.ok("Collaborateur archivé avec succès");
    }

    // Récupérer les collaborateurs actifs
    public List<Collaborateur> getCollaborateursActifs() {
        return collaborateurRepository.findByDeletedFalse();
    }

    // Récupérer les collaborateurs supprimés (corbeille)
    public List<Collaborateur> getCollaborateursSupprimes() {
        return collaborateurRepository.findByDeletedTrue();
    }
    */
    

    
}
