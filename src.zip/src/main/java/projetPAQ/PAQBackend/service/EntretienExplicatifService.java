package projetPAQ.PAQBackend.service;

import projetPAQ.PAQBackend.DTO.EntretienExplicatifDTO;
import projetPAQ.PAQBackend.entity.EntretienExplicatif;
import projetPAQ.PAQBackend.repository.EntretienExplicatifRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service

public class EntretienExplicatifService {

    private final EntretienExplicatifRepository entretienExplicatifRepository;

    public EntretienExplicatifService(EntretienExplicatifRepository entretienExplicatifRepository) {
        this.entretienExplicatifRepository = entretienExplicatifRepository;
    }

   /* public List<EntretienExplicatif> getAllEntretiens() {
        return entretienExplicatifRepository.findAll();
    }*/
/*
    public Optional<EntretienExplicatif> getEntretienById(Integer id) {
        return entretienExplicatifRepository.findById(id);
    }
*/
    public EntretienExplicatif createEntretien(EntretienExplicatif entretien, String userRole) {
        if (!"SL".equals(userRole) && !"SGL".equals(userRole)) {
            throw new RuntimeException("Seuls les utilisateurs avec le rôle SL ou SGL peuvent ajouter un entretien explicatif.");
        }
        return entretienExplicatifRepository.save(entretien);
    }

   /* public Optional<EntretienExplicatif> updateEntretien(Integer id, EntretienExplicatif newEntretien) {
        return entretienExplicatifRepository.findById(id).map(entretien -> {
            entretien.setDate(newEntretien.getDate());
            entretien.setTypeErreur(newEntretien.getTypeErreur());
            entretien.setDetails(newEntretien.getDetails());
            entretien.setDecision(newEntretien.getDecision());
            entretien.setCollaborateur(newEntretien.getCollaborateur());
            entretien.setUser(newEntretien.getUser());
            return entretienExplicatifRepository.save(entretien);
        });
    }*/
 // Votre méthode de mise à jour
    public Optional<EntretienExplicatif> updateEntretien(Integer id, EntretienExplicatif updatedEntretien) {
        if (entretienExplicatifRepository.existsById(id)) {
            updatedEntretien.setId(id);
            return Optional.of(entretienExplicatifRepository.save(updatedEntretien));
        }
        return Optional.empty();
    }
    public EntretienExplicatifDTO convertToDTO(EntretienExplicatif entretien) {
        EntretienExplicatifDTO dto = new EntretienExplicatifDTO();
        dto.setId(entretien.getId());
        dto.setDate(entretien.getDate());
        dto.setTypeErreur(entretien.getTypeErreur());
        dto.setDetails(entretien.getDetails());
        dto.setDecision(entretien.getDecision());
        dto.setCollaborateurId(entretien.getCollaborateur().getId());
        dto.setUserId(entretien.getUser().getId());
        dto.setValidated(entretien.isValidated()); 
        return dto;
    }

   /* public void deleteEntretien(Integer id) {
        entretienExplicatifRepository.deleteById(id);
    }*/
    
    public void deleteEntretien(Integer id) {
        Optional<EntretienExplicatif> entretienOptional = entretienExplicatifRepository.findById(id);
        if (entretienOptional.isPresent()) {
            EntretienExplicatif entretien = entretienOptional.get();
            entretien.setDeleted(true); // Marquer comme supprimé
            entretienExplicatifRepository.save(entretien); // Sauvegarder les modifications
        }
    }
    public List<EntretienExplicatif> getAllEntretiens() {
        return entretienExplicatifRepository.findByDeletedFalse(); // Récupérer uniquement les entretiens non supprimés
    }

    public Optional<EntretienExplicatif> getEntretienById(Integer id) {
        return entretienExplicatifRepository.findByIdAndDeletedFalse(id); // Récupérer uniquement si non supprimé
    }

    public List<EntretienExplicatif> getEntretiensByCollaborateurId(Integer collaborateurId) {
        List<EntretienExplicatif> entretiens = entretienExplicatifRepository.findByCollaborateurId(collaborateurId);
        
        // Filtrer les entretiens pour ne retourner que ceux qui ne sont pas supprimés
        return entretiens.stream()
                         .filter(entretien -> !entretien.isDeleted())
                         .collect(Collectors.toList());
    }
    public void restoreEntretien(Integer id) {
        Optional<EntretienExplicatif> entretienOptional = entretienExplicatifRepository.findById(id);
        if (entretienOptional.isPresent()) {
            EntretienExplicatif entretien = entretienOptional.get();
            entretien.setDeleted(false); // Marquer comme non supprimé
            entretienExplicatifRepository.save(entretien); // Sauvegarder les modifications
        }
    }
    
  /*  public List<EntretienExplicatif> getEntretiensByCollaborateurId(Integer collaborateurId) {
        return entretienExplicatifRepository.findByCollaborateurId(collaborateurId);
    }*/
    
    
   // Ajouter la méthode findById
    public Optional<EntretienExplicatif> findById(Integer id) {
        return entretienExplicatifRepository.findById(id);
    }
    
    public Optional<EntretienExplicatif> validateEntretien(Integer id, String userRole) {
        // Vérifier que l'utilisateur a le rôle approprié (SL ou SGL)
        if (!"SL".equals(userRole) && !"SGL".equals(userRole)) {
            throw new RuntimeException("Seuls les utilisateurs avec le rôle SL ou SGL peuvent valider un entretien explicatif.");
        }

        // Récupérer l'entretien par son ID
        Optional<EntretienExplicatif> entretienOptional = entretienExplicatifRepository.findById(id);

        if (entretienOptional.isPresent()) {
            EntretienExplicatif entretien = entretienOptional.get();
            entretien.setValidated(true); // Mettre à jour le champ validated
            entretienExplicatifRepository.save(entretien); // Sauvegarder les modifications
            return Optional.of(entretien);
        }

        return Optional.empty(); // Retourner un Optional vide si l'entretien n'existe pas
    }
    
    
    public List<EntretienExplicatif> getEntretiensByUserIdAndNotDeleted(Integer userId) {
        return entretienExplicatifRepository.findByUserIdAndDeletedFalse(userId);
    }
    
    public List<EntretienExplicatif> getDeletedEntretiensByUserId(Integer userId) {
        return entretienExplicatifRepository.findByUserIdAndDeletedTrue(userId);
    }

}